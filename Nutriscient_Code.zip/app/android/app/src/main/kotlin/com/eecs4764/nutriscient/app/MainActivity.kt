package com.eecs4764.nutriscient.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
